"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, GraduationCap, BookOpen, Award, Building } from "lucide-react"

export default function Navigation() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/mba-universities", label: "MBA Universities", icon: GraduationCap },
    { href: "/online-degrees", label: "Online Degrees", icon: BookOpen },
    { href: "/scholarships", label: "Scholarships", icon: Award },
    { href: "/engineering-colleges", label: "Engineering Colleges", icon: Building },
  ]

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="font-bold text-xl text-gray-800">
            Education Hub
          </Link>

          <div className="hidden md:flex space-x-8">
            {navItems.map((item) => {
              const IconComponent = item.icon
              const isActive = pathname === item.href

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive ? "text-blue-600 bg-blue-50" : "text-gray-600 hover:text-blue-600 hover:bg-gray-50"
                  }`}
                >
                  <IconComponent className="w-4 h-4" />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </nav>
  )
}

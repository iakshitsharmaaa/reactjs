"use client"

import type React from "react"

import { useEffect } from "react"

interface ArticleLayoutProps {
  children: React.ReactNode
}

export default function ArticleLayout({ children }: ArticleLayoutProps) {
  useEffect(() => {
    // Load article styles
    const link = document.createElement("link")
    link.rel = "stylesheet"
    link.href = "/styles/article-styles.css"
    document.head.appendChild(link)

    // Scroll to top
    window.scrollTo(0, 0)

    return () => {
      // Cleanup
      document.head.removeChild(link)
    }
  }, [])

  return <div className="min-h-screen">{children}</div>
}

"use client"

import { useState, useEffect } from "react"
import { SettingsStore } from "@/lib/settings-store"

export default function Footer() {
  const [footerText, setFooterText] = useState(
    "© 2024 EduGuide.com. All rights reserved. Your trusted source for educational guidance worldwide.",
  )

  useEffect(() => {
    const settingsStore = SettingsStore.getInstance()
    setFooterText(settingsStore.getFooterText())
  }, [])

  return (
    <footer className="bg-gray-800 text-white py-6 md:py-8 mt-12 md:mt-16">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <p className="text-gray-400 text-sm md:text-base">{footerText}</p>
      </div>
    </footer>
  )
}

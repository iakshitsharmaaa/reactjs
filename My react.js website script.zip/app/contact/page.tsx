"use client"

import { useState, useEffect } from "react"
import { PagesStore } from "@/lib/pages-store"

export default function ContactPage() {
  const [content, setContent] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const pagesStore = PagesStore.getInstance()
    const contactPage = pagesStore.getPageBySlug("contact")

    if (contactPage) {
      setContent(contactPage.content)
    }
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <article className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 border border-gray-100">
          <div className="prose prose-lg max-w-none">
            {content.split("\n").map((line, index) => {
              if (line.startsWith("# ")) {
                return (
                  <h1
                    key={index}
                    className="text-3xl md:text-4xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"
                  >
                    {line.substring(2)}
                  </h1>
                )
              } else if (line.startsWith("## ")) {
                return (
                  <h2 key={index} className="text-2xl font-bold mt-8 mb-4 text-gray-800">
                    {line.substring(3)}
                  </h2>
                )
              } else if (line.startsWith("**") && line.endsWith("**")) {
                return (
                  <p key={index} className="font-semibold text-gray-800 mb-2">
                    {line.substring(2, line.length - 2)}
                  </p>
                )
              } else if (line.startsWith("- ")) {
                return (
                  <li key={index} className="text-gray-600 mb-2">
                    {line.substring(2)}
                  </li>
                )
              } else if (line.trim() === "") {
                return <br key={index} />
              } else {
                return (
                  <p key={index} className="text-gray-600 mb-4 leading-relaxed">
                    {line}
                  </p>
                )
              }
            })}
          </div>
        </div>
      </article>
    </div>
  )
}

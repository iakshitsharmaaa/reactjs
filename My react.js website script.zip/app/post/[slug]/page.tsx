"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { PostsStore, type Post } from "@/lib/posts-store"
import ArticleLayout from "@/components/article-layout"
import Link from "next/link"

export default function PostPage() {
  const params = useParams()
  const [post, setPost] = useState<Post | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const postsStore = PostsStore.getInstance()
    const foundPost = postsStore.getPostBySlug(params.slug as string)
    setPost(foundPost || null)
    setLoading(false)
  }, [params.slug])

  const formatContent = (content: string) => {
    return content
      .split("\n\n")
      .map((paragraph, index) => {
        if (paragraph.startsWith("## ")) {
          return `<h2>${paragraph.replace("## ", "")}</h2>`
        }
        if (paragraph.startsWith("# ")) {
          return `<h1>${paragraph.replace("# ", "")}</h1>`
        }
        return `<p>${paragraph.replace(/\*\*(.*?)\*\*/g, '<span class="university-name">$1</span>')}</p>`
      })
      .join("")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Post Not Found</h1>
          <Link href="/" className="text-blue-600 hover:underline">
            Go back to home
          </Link>
        </div>
      </div>
    )
  }

  return (
    <ArticleLayout>
      <article>
        <h1>{post.title}</h1>
        <div
          dangerouslySetInnerHTML={{
            __html: formatContent(post.content),
          }}
        />
      </article>
    </ArticleLayout>
  )
}

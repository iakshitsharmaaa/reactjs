"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AuthStore } from "@/lib/auth-store"

export default function AdminLoginPage() {
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  })
  const [error, setError] = useState("")
  const [showResetForm, setShowResetForm] = useState(false)
  const [resetData, setResetData] = useState({
    username: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [resetMessage, setResetMessage] = useState("")

  const router = useRouter()
  const authStore = AuthStore.getInstance()

  useEffect(() => {
    if (authStore.isAuthenticated()) {
      router.push("/admin")
    }
  }, [])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    const success = authStore.login(credentials.username, credentials.password)

    if (success) {
      router.push("/admin")
    } else {
      setError("Invalid username or password")
    }
  }

  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault()
    setResetMessage("")

    if (resetData.newPassword !== resetData.confirmPassword) {
      setResetMessage("Passwords don't match")
      return
    }

    if (resetData.newPassword.length < 6) {
      setResetMessage("Password must be at least 6 characters long")
      return
    }

    const success = authStore.resetPassword(resetData.username, resetData.newPassword)

    if (success) {
      setResetMessage("Password reset successfully! You can now login with your new password.")
      setShowResetForm(false)
      setResetData({ username: "", newPassword: "", confirmPassword: "" })
    } else {
      setResetMessage("Username not found")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <div className="text-center">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Admin Login
            </h2>
            <p className="mt-2 text-sm text-gray-600">Sign in to access the admin panel</p>
          </div>

          {!showResetForm ? (
            <form className="mt-8 space-y-6" onSubmit={handleLogin}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                    Username
                  </label>
                  <input
                    id="username"
                    name="username"
                    type="text"
                    required
                    value={credentials.username}
                    onChange={(e) => setCredentials((prev) => ({ ...prev, username: e.target.value }))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Enter your username"
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    value={credentials.password}
                    onChange={(e) => setCredentials((prev) => ({ ...prev, password: e.target.value }))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Enter your password"
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
              )}

              {resetMessage && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
                  {resetMessage}
                </div>
              )}

              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-all duration-200"
                >
                  Sign In
                </button>
              </div>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => setShowResetForm(true)}
                  className="text-sm text-purple-600 hover:text-purple-500 font-medium"
                >
                  Forgot your password?
                </button>
              </div>
            </form>
          ) : (
            <form className="mt-8 space-y-6" onSubmit={handlePasswordReset}>
              <div className="text-center">
                <h3 className="text-lg font-medium text-gray-900">Reset Password</h3>
                <p className="mt-1 text-sm text-gray-600">Enter your username and new password</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label htmlFor="reset-username" className="block text-sm font-medium text-gray-700">
                    Username
                  </label>
                  <input
                    id="reset-username"
                    name="reset-username"
                    type="text"
                    required
                    value={resetData.username}
                    onChange={(e) => setResetData((prev) => ({ ...prev, username: e.target.value }))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Enter your username"
                  />
                </div>

                <div>
                  <label htmlFor="new-password" className="block text-sm font-medium text-gray-700">
                    New Password
                  </label>
                  <input
                    id="new-password"
                    name="new-password"
                    type="password"
                    required
                    value={resetData.newPassword}
                    onChange={(e) => setResetData((prev) => ({ ...prev, newPassword: e.target.value }))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Enter new password"
                  />
                </div>

                <div>
                  <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700">
                    Confirm New Password
                  </label>
                  <input
                    id="confirm-password"
                    name="confirm-password"
                    type="password"
                    required
                    value={resetData.confirmPassword}
                    onChange={(e) => setResetData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Confirm new password"
                  />
                </div>
              </div>

              {resetMessage && (
                <div
                  className={`px-4 py-3 rounded-lg text-sm ${
                    resetMessage.includes("successfully")
                      ? "bg-green-50 border border-green-200 text-green-700"
                      : "bg-red-50 border border-red-200 text-red-700"
                  }`}
                >
                  {resetMessage}
                </div>
              )}

              <div className="flex space-x-4">
                <button
                  type="submit"
                  className="flex-1 flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-all duration-200"
                >
                  Reset Password
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowResetForm(false)
                    setResetData({ username: "", newPassword: "", confirmPassword: "" })
                    setResetMessage("")
                  }}
                  className="flex-1 flex justify-center py-3 px-4 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-all duration-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">Default credentials: admin / admin123</p>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { PostsStore, type Post } from "@/lib/posts-store"

export default function AllPostsPage() {
  const [posts, setPosts] = useState<Post[]>([])

  useEffect(() => {
    const postsStore = PostsStore.getInstance()
    setPosts(postsStore.getAllPosts())
  }, [])

  const postsPerPage = 10
  const totalPosts = posts.length
  const showPagination = totalPosts > postsPerPage

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <article className="px-4 md:px-8">
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-center mb-6 md:mb-8 text-gray-800 pt-8">
          All Posts
        </h1>

        <div className="space-y-6 md:space-y-8 max-w-4xl mx-auto">
          {posts.slice(0, postsPerPage).map((post, index) => {
            return (
              <div
                key={post.id}
                className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-gray-100 hover:border-purple-200 transform hover:-translate-y-2"
              >
                {/* Post Header */}
                <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 p-6 text-white">
                  <span className="inline-block px-4 py-2 text-xs font-semibold bg-white/20 backdrop-blur-sm rounded-full mb-4">
                    {post.category}
                  </span>
                  <h2 className="text-xl md:text-2xl font-bold leading-tight text-white">{post.title}</h2>
                </div>

                {/* Post Content */}
                <div className="p-6 md:p-8">
                  <p className="text-gray-600 leading-relaxed mb-6 text-sm md:text-base">{post.excerpt}</p>
                  <div className="flex justify-center">
                    <Link
                      href={`/post/${post.slug}`}
                      className="group inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      <span>Read Complete Guide</span>
                      <svg
                        className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-300"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 8l4 4m0 0l-4 4m4-4H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Pagination - Only shows when more than 10 posts */}
        {showPagination && (
          <div className="flex justify-center mt-8 md:mt-12 px-4">
            <nav className="flex items-center space-x-1 md:space-x-2 overflow-x-auto">
              <button className="px-3 md:px-4 py-2 text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm whitespace-nowrap">
                Previous
              </button>
              <button className="px-3 md:px-4 py-2 text-white bg-purple-600 border border-purple-600 rounded-lg text-sm">
                1
              </button>
              <button className="px-3 md:px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                2
              </button>
              <button className="px-3 md:px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm whitespace-nowrap">
                Next
              </button>
            </nav>
          </div>
        )}

        {/* Show total posts count */}
        <div className="text-center mt-6 text-sm text-gray-500 pb-8">
          Showing {Math.min(postsPerPage, totalPosts)} of {totalPosts} posts
        </div>
      </article>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { PostsStore, type Post } from "@/lib/posts-store"

export default function HomePage() {
  const [posts, setPosts] = useState<Post[]>([])

  useEffect(() => {
    const postsStore = PostsStore.getInstance()
    setPosts(postsStore.getAllPosts().slice(0, 4)) // Show only first 4 posts on homepage
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Main Content */}
      <div className="max-w-4xl mx-auto py-4 md:py-8 px-4">
        <h1 className="text-2xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-gray-800">
          Latest Educational Guides
        </h1>

        {/* Posts List */}
        <div className="space-y-6 md:space-y-8">
          {posts.map((post, index) => {
            return (
              <article
                key={post.id}
                className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden border border-gray-100 hover:border-purple-200 transform hover:-translate-y-2"
              >
                {/* Post Header */}
                <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 p-6 text-white">
                  <span className="inline-block px-4 py-2 text-xs font-semibold bg-white/20 backdrop-blur-sm rounded-full mb-4">
                    {post.category}
                  </span>
                  <h2 className="text-xl md:text-2xl font-bold leading-tight text-white">
                    <Link href={`/post/${post.slug}`}>{post.title}</Link>
                  </h2>
                </div>

                {/* Post Content */}
                <div className="p-6 md:p-8">
                  <p className="text-gray-600 leading-relaxed mb-6 text-justify text-sm md:text-base">{post.excerpt}</p>

                  {/* Read More Button */}
                  <div className="flex justify-center">
                    <Link
                      href={`/post/${post.slug}`}
                      className="inline-flex items-center justify-center px-6 md:px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 text-sm md:text-base"
                    >
                      Read Complete Guide
                      <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 8l4 4m0 0l-4 4m4-4H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </article>
            )
          })}
        </div>
      </div>
    </div>
  )
}

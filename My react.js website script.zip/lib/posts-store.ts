"use client"

export interface Post {
  id: string
  title: string
  content: string
  excerpt: string
  category: string
  slug: string
  createdAt: string
}

const POSTS_STORAGE_KEY = "eduguide_posts"

// Default posts
const defaultPosts: Post[] = [
  {
    id: "1",
    title: "Top MBA Universities in World",
    slug: "mba-universities",
    category: "MBA Programs",
    excerpt:
      "The pursuit of a Master of Business Administration (MBA) degree represents one of the most significant investments in one's professional future, offering transformative opportunities for career advancement, leadership development, and global networking.",
    content: `The pursuit of a Master of Business Administration (MBA) degree represents one of the most significant investments in one's professional future, offering transformative opportunities for career advancement, leadership development, and global networking. With thousands of institutions worldwide offering MBA programs, selecting the right university requires careful consideration of numerous factors including academic reputation, faculty expertise, alumni networks, career services, and return on investment.

The landscape of MBA education has evolved dramatically over the past century, transforming from specialized business training programs into comprehensive leadership development experiences that prepare graduates for executive roles across diverse industries.

## Harvard Business School, United States

Harvard Business School stands as the undisputed pioneer and gold standard in MBA education, having established the case study method that has become synonymous with business education worldwide. Founded in 1908, Harvard Business School has consistently maintained its position at the apex of business education.

The Harvard MBA experience is built around the intensive case study method, where students analyze over 500 real business situations annually, developing critical thinking skills and decision-making capabilities that prove invaluable throughout their careers.`,
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    title: "Best Online Degree Programs",
    slug: "online-degrees",
    category: "Online Education",
    excerpt:
      "The digital transformation of higher education has revolutionized how students access quality education, breaking down geographical barriers and creating flexible learning opportunities.",
    content: `The digital transformation of higher education has revolutionized how students access quality education, breaking down geographical barriers and creating flexible learning opportunities that accommodate diverse lifestyles and career demands.

Online degree programs have evolved from experimental alternatives to mainstream educational options embraced by prestigious universities, millions of students, and employers worldwide.

## Arizona State University Online

Arizona State University Online has emerged as the undisputed leader in online higher education, offering over 300 degree programs that span undergraduate, graduate, and doctoral levels across virtually every academic discipline.`,
    createdAt: new Date().toISOString(),
  },
  {
    id: "3",
    title: "Scholarships for International Students",
    slug: "scholarships",
    category: "Scholarships",
    excerpt:
      "The pursuit of international education represents one of the most transformative experiences available to students, offering exposure to diverse cultures and world-class academic programs.",
    content: `The pursuit of international education represents one of the most transformative experiences available to students, offering exposure to diverse cultures, world-class academic programs, cutting-edge research opportunities, and global career prospects.

However, the financial investment required for international education can be substantial, encompassing tuition fees, living expenses, travel costs, and various other expenses that can create significant barriers for many deserving students.

## Fulbright Foreign Student Program

The Fulbright Foreign Student Program stands as the most prestigious and comprehensive scholarship opportunity for international students seeking graduate-level study and research in the United States.`,
    createdAt: new Date().toISOString(),
  },
  {
    id: "4",
    title: "Engineering Colleges with Highest Placement",
    slug: "engineering-colleges",
    category: "Engineering",
    excerpt:
      "In today's rapidly evolving technological landscape, the placement record of an engineering college serves as one of the most critical indicators of institutional quality.",
    content: `In today's rapidly evolving technological landscape, the placement record of an engineering college serves as one of the most critical indicators of institutional quality, industry relevance, and graduate preparedness for successful careers in engineering and technology fields.

The most prestigious engineering institutions worldwide have established themselves not only through academic excellence and cutting-edge research but also through their ability to consistently place graduates in highly sought-after positions.

## Massachusetts Institute of Technology

Massachusetts Institute of Technology stands as the undisputed global leader in engineering education, consistently ranking first in virtually every engineering discipline and maintaining placement records that are unmatched by any other institution worldwide.`,
    createdAt: new Date().toISOString(),
  },
]

export class PostsStore {
  private static instance: PostsStore
  private posts: Post[] = []

  private constructor() {
    this.loadPosts()
  }

  static getInstance(): PostsStore {
    if (!PostsStore.instance) {
      PostsStore.instance = new PostsStore()
    }
    return PostsStore.instance
  }

  private loadPosts() {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(POSTS_STORAGE_KEY)
      if (stored) {
        this.posts = JSON.parse(stored)
      } else {
        this.posts = defaultPosts
        this.savePosts()
      }
    } else {
      this.posts = defaultPosts
    }
  }

  private savePosts() {
    if (typeof window !== "undefined") {
      localStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(this.posts))
    }
  }

  getAllPosts(): Post[] {
    return [...this.posts]
  }

  getPostBySlug(slug: string): Post | undefined {
    return this.posts.find((post) => post.slug === slug)
  }

  addPost(post: Omit<Post, "id" | "createdAt">): Post {
    const newPost: Post = {
      ...post,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    this.posts.unshift(newPost)
    this.savePosts()
    return newPost
  }

  updatePost(id: string, updates: Partial<Post>): Post | null {
    const index = this.posts.findIndex((post) => post.id === id)
    if (index === -1) return null

    this.posts[index] = { ...this.posts[index], ...updates }
    this.savePosts()
    return this.posts[index]
  }

  deletePost(id: string): boolean {
    const index = this.posts.findIndex((post) => post.id === id)
    if (index === -1) return false

    this.posts.splice(index, 1)
    this.savePosts()
    return true
  }
}

export interface SiteSettings {
  siteName: string
  siteDescription: string
  contactEmail: string
  contactPhone: string
  footerText: string
}

export class SettingsStore {
  private static instance: SettingsStore
  private settings: SiteSettings

  private constructor() {
    this.settings = this.loadSettings()
  }

  static getInstance(): SettingsStore {
    if (!SettingsStore.instance) {
      SettingsStore.instance = new SettingsStore()
    }
    return SettingsStore.instance
  }

  private loadSettings(): SiteSettings {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("site-settings")
      if (saved) {
        return JSON.parse(saved)
      }
    }

    return {
      siteName: "EduGuide.com",
      siteDescription: "Your trusted source for educational guidance worldwide.",
      contactEmail: "info@eduguide.com",
      contactPhone: "+1 (555) 123-4567",
      footerText: "© 2024 EduGuide.com. All rights reserved. Your trusted source for educational guidance worldwide.",
    }
  }

  private saveSettings(): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("site-settings", JSON.stringify(this.settings))
    }
  }

  getSettings(): SiteSettings {
    return { ...this.settings }
  }

  getSiteName(): string {
    return this.settings.siteName
  }

  getFooterText(): string {
    return this.settings.footerText
  }

  updateSettings(newSettings: Partial<SiteSettings>): void {
    this.settings = { ...this.settings, ...newSettings }
    this.saveSettings()
  }
}

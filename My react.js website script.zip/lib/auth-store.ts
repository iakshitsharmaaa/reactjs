"use client"

export interface AuthUser {
  username: string
  isAuthenticated: boolean
  loginTime: number
}

const AUTH_STORAGE_KEY = "eduguide_auth"
const ADMIN_CREDENTIALS = {
  username: "iakshitsharma",
  password: "@Papa143@",
}

// Session expires after 24 hours
const SESSION_DURATION = 24 * 60 * 60 * 1000

export class AuthStore {
  private static instance: AuthStore
  private currentUser: AuthUser | null = null

  private constructor() {
    this.loadAuth()
  }

  static getInstance(): AuthStore {
    if (!AuthStore.instance) {
      AuthStore.instance = new AuthStore()
    }
    return AuthStore.instance
  }

  private loadAuth() {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY)
      if (stored) {
        const user: AuthUser = JSON.parse(stored)
        // Check if session is still valid
        if (Date.now() - user.loginTime < SESSION_DURATION) {
          this.currentUser = user
        } else {
          // Session expired
          this.logout()
        }
      }
    }
  }

  private saveAuth() {
    if (typeof window !== "undefined" && this.currentUser) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(this.currentUser))
    }
  }

  login(username: string, password: string): boolean {
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      this.currentUser = {
        username,
        isAuthenticated: true,
        loginTime: Date.now(),
      }
      this.saveAuth()
      return true
    }
    return false
  }

  logout() {
    this.currentUser = null
    if (typeof window !== "undefined") {
      localStorage.removeItem(AUTH_STORAGE_KEY)
    }
  }

  isAuthenticated(): boolean {
    if (!this.currentUser) return false

    // Check if session is still valid
    if (Date.now() - this.currentUser.loginTime >= SESSION_DURATION) {
      this.logout()
      return false
    }

    return this.currentUser.isAuthenticated
  }

  getCurrentUser(): AuthUser | null {
    return this.currentUser
  }

  changePassword(currentPassword: string, newPassword: string): boolean {
    if (currentPassword !== ADMIN_CREDENTIALS.password) {
      return false
    }
    // In a real app, you'd update this in a database
    // For now, we'll just update the local reference
    ;(ADMIN_CREDENTIALS as any).password = newPassword

    // Force re-login with new password
    this.logout()
    return true
  }

  resetPassword(username: string, secretAnswer: string): string | null {
    // Simple security question - in real app, use proper reset mechanism
    if (username === ADMIN_CREDENTIALS.username && secretAnswer.toLowerCase() === "papa") {
      const newPassword = "NewAdmin@123"
      ;(ADMIN_CREDENTIALS as any).password = newPassword
      return newPassword
    }
    return null
  }
}

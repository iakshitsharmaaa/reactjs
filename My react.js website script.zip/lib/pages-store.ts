export interface Page {
  id: string
  title: string
  slug: string
  content: string
  isPublished: boolean
  createdAt: string
  updatedAt: string
}

export class PagesStore {
  private static instance: PagesStore
  private pages: Page[] = []

  private constructor() {
    this.loadPages()
  }

  static getInstance(): PagesStore {
    if (!PagesStore.instance) {
      PagesStore.instance = new PagesStore()
    }
    return PagesStore.instance
  }

  private loadPages(): void {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("pages")
      if (saved) {
        this.pages = JSON.parse(saved)
      } else {
        this.pages = this.getDefaultPages()
        this.savePages()
      }
    }
  }

  private savePages(): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("pages", JSON.stringify(this.pages))
    }
  }

  private getDefaultPages(): Page[] {
    return [
      {
        id: "1",
        title: "About Us",
        slug: "about",
        content: `# About EduGuide.com

Welcome to EduGuide.com, your trusted partner in educational excellence and career development.

## Our Mission

We are dedicated to providing comprehensive, accurate, and up-to-date information about educational opportunities worldwide. Our mission is to help students, professionals, and lifelong learners make informed decisions about their educational journey.

## What We Offer

- **University Guides**: Detailed information about top universities and colleges
- **Program Reviews**: In-depth analysis of academic programs
- **Admission Guidance**: Step-by-step application processes
- **Scholarship Information**: Financial aid and scholarship opportunities
- **Career Advice**: Professional development and career planning

## Our Team

Our team consists of education experts, career counselors, and industry professionals who are passionate about helping others achieve their educational goals.

## Contact Us

Have questions? We're here to help! Reach out to us through our contact page or email us directly.`,
        isPublished: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "2",
        title: "Contact Us",
        slug: "contact",
        content: `# Contact Us

We'd love to hear from you! Get in touch with our team for any questions, suggestions, or collaboration opportunities.

## Get In Touch

**Email**: info@eduguide.com  
**Phone**: +1 (555) 123-4567  
**Address**: 123 Education Street, Learning City, LC 12345

## Office Hours

- **Monday - Friday**: 9:00 AM - 6:00 PM
- **Saturday**: 10:00 AM - 4:00 PM
- **Sunday**: Closed

## Quick Contact Form

For immediate assistance, please use our contact form below or send us an email directly. We typically respond within 24 hours.

## Follow Us

Stay connected with us on social media for the latest updates and educational tips.

We look forward to helping you on your educational journey!`,
        isPublished: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ]
  }

  getAllPages(): Page[] {
    return [...this.pages]
  }

  getPublishedPages(): Page[] {
    return this.pages.filter((page) => page.isPublished)
  }

  getPageBySlug(slug: string): Page | null {
    return this.pages.find((page) => page.slug === slug && page.isPublished) || null
  }

  addPage(pageData: Omit<Page, "id" | "createdAt" | "updatedAt">): Page {
    const newPage: Page = {
      ...pageData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    this.pages.push(newPage)
    this.savePages()
    return newPage
  }

  updatePage(id: string, pageData: Partial<Omit<Page, "id" | "createdAt">>): boolean {
    const index = this.pages.findIndex((page) => page.id === id)
    if (index !== -1) {
      this.pages[index] = {
        ...this.pages[index],
        ...pageData,
        updatedAt: new Date().toISOString(),
      }
      this.savePages()
      return true
    }
    return false
  }

  deletePage(id: string): boolean {
    const index = this.pages.findIndex((page) => page.id === id)
    if (index !== -1) {
      this.pages.splice(index, 1)
      this.savePages()
      return true
    }
    return false
  }
}
